<?php
/**
 * Class AI_Content_Generator_Test
 *
 * @package Ai_Content_Generator
 */

/**
 * Sample test case.
 */
class AI_Content_Generator_Test extends WP_UnitTestCase {

	/**
	 * A single example test.
	 */
	function test_sample() {
		// Replace this with some actual testing code.
		$this->assertTrue( true );
	}
}
